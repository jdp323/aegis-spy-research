# AEGIS expert technical review — 31 October 2026

Start with the PDF or Markdown. They contain the same frozen 30-section report and six evidence annexes. The observations have their own timestamps; this package does not retime old evidence as current.

## Evidence and reproduction limits

- `AEGIS_PINNED_SOURCE_b234f66.zip`: exact 422-file public code/documentation baseline, revision b234f6672bc20d931b9862249bcf9cbdb3fcab38, tree 2eb0a79c065ffa7c6d67af369efcc548221b5437. This predates the documentation-only report publication.
- `AEGIS_EXPERT_INDEX_2026-10-31.json`: source hashes, observed parameters, evidence summaries and separately timestamped operations/probes. It is an index, not the raw private databases or an independently certified audit.
- `source_inventory.csv` / `symbol_inventory.csv`: file and Python-symbol navigation. An index entry does not prove correctness or test coverage.
- `normalized_source_comparison.json` / `deployment_profile_diff.txt`: installed versus portable differences. The diff is privacy-redacted and nonexecutable; the profiles are not claimed identical. Do not apply it as a deployment patch.
- `market_data_probe.json`: three read-only requests using the existing authorized credential mechanism. A response does not establish freshness; SIP/OPRA were refused.
- `qa_visual.json`: PDF text-bounds, rendered-page and visual review results. Host font mapping warnings are disclosed.
- `publication_verification.json`: fetched GitHub head/tree and exact public document verification. The source baseline and the later documentation commit are distinct.

No complete suites or strategy replays were rerun for this report. Dated results, original failures, retrospective assumptions, missing genuine option history and synthetic formatter fixtures remain clearly identified. A passing software test is not evidence of profitability. The latest observed worker cycle missed its budget; live readiness remains unestablished.

No credentials, recipient IDs, actual-fill ledgers, databases, outboxes, private receipts, raw market caches or machine-specific deployment paths are supplied. Genuine option outcome replication remains blocked by the missing required point-in-time dataset. Underlying outcomes do not prove option outcomes. A research state is not a personal holding.

The archive grants no authority to start services, contact Telegram recipients, inspect brokerage accounts, alter permissions, place orders or promote live signals. Manual execution and current live/option gates remain in force. Preserve existing history and review source-specific licenses before reuse.

`SHA256SUMS.txt` binds every supplied member other than itself. Verify the extracted files before review; it is an integrity manifest, not a security certification.
